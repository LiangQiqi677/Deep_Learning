ex5_lstm.py：使用LSTM实现实验5
ex5_gru.py：使用GRU实现实验5
ex5_TextCNN.py：使用CNN实现实验5
word2vec.py：简单实现Word2Vec（实验中未使用到）
negative_sampling.py：带有负采样的Word2Vec（实验中未使用到）

由于上传的文件有大小限制，故以下模型的结构和参数均不含在其中
#ex5_0.pt：LSTM模型保存的结构和参数
#ex5_1.pt：GRU模型保存的结构和参数
#ex5_2.pt：CNN模型保存的结构和参数
#word2vec_model.txt：Word2Vec保存的结构和参数（通过gensim.Word2Vec生成）

